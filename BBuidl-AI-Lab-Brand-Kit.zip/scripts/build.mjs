import { mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import opentype from 'opentype.js';
import { Resvg } from '@resvg/resvg-js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const fonts = Object.fromEntries(['Bold', 'Semibold', 'Medium'].map(w => [w, opentype.loadSync(resolve(root, `assets/fonts/Manrope-${w}.ttf`))]));
const C = { forest: '#183E35', paper: '#F4F1E9', lime: '#D9EF87', muted: '#748078', line: '#D7DBD1', white: '#FFFFFF', black: '#111111' };
const esc = s => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('"', '&quot;');
// A single compound path prevents antialiasing seams between shared contours.
// Four true counters keep every version transparent and colour-independent.
const contour = 'M0 0H61C99 0 121 13 121 36C121 49 116 58 105 64C119 70 127 80 127 95C127 121 106 134 65 134H0Z';
const counters = 'M20 18V55H40C56 55 65 49 65 36C65 24 57 18 40 18ZM20 74V116H44C62 116 71 109 71 95C71 81 62 74 44 74Z';
const channels = 'M68 19C85 28 89 42 79 54C94 52 101 46 101 36C101 26 88 20 68 19ZM76 75C91 86 95 102 82 114C99 112 107 106 107 95C107 84 95 77 76 75Z';
// Optical master: widened channels, simpler counters and stronger spine for tiny UI.
const microCounters = 'M22 20V54H39C54 54 61 48 61 36C61 25 54 20 39 20ZM22 77V114H43C59 114 67 108 67 95C67 83 59 77 43 77Z';
const microChannels = 'M66 18C77 29 79 43 69 55C89 54 101 48 101 36C101 25 88 19 66 18ZM73 76C84 86 88 103 75 115C97 113 107 107 107 95C107 84 94 78 73 76Z';

function text(str,x,y,size,color=C.forest,weight='Medium',tracking=0) {
  const font=fonts[weight]; let cursor=x; let d='';
  const glyphs=font.stringToGlyphs(str);
  glyphs.forEach((glyph,i)=>{
    d+=glyph.getPath(cursor,y,size).toPathData(3);
    cursor+=glyph.advanceWidth/font.unitsPerEm*size+tracking;
    if(i<glyphs.length-1) cursor+=font.getKerningValue(glyph,glyphs[i+1])/font.unitsPerEm*size;
  });
  return `<path aria-label="${esc(str)}" fill="${color}" d="${d}"/>`;
}
function rect(x,y,w,h,fill,rx=0) { return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}"/>`; }
function line(x1,y1,x2,y2,color=C.line) { return `<path d="M${x1} ${y1}H${x2}" transform="${y2===y1?'':`rotate(${Math.atan2(y2-y1,x2-x1)*180/Math.PI} ${x1} ${y1})`}" stroke="${color}"/>`; }
function mark(x,y,height,color=C.forest,micro=false) {
  return `<path transform="translate(${x} ${y}) scale(${height/134})" fill="${color}" fill-rule="evenodd" d="${contour}${micro?microCounters:counters}${micro?microChannels:channels}"/>`;
}
function lockup(x,y,height,color=C.forest) {
  const scale=height/134;
  return `<g transform="translate(${x} ${y}) scale(${scale})">${mark(0,0,134,color)}${text('BBuidl',169,84,106,color,'Bold',-4.1)}${text('AI LAB',174,128,24,color,'Semibold',6.8)}</g>`;
}
function compact(x,y,height,color=C.forest) {
  const scale=height/60;
  return `<g transform="translate(${x} ${y}) scale(${scale})">${mark(0,0,60,color)}${text('BBuidl',76,44,52,color,'Bold',-2)}${text('AI LAB',249,43,19,color,'Semibold',1.8)}</g>`;
}
function svg(w,h,body,title='BBuidl AI Lab',desc='BB monogram and wordmark. Original vector identity for BBuidl AI Lab, BBuidl.xyz.') {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" role="img" aria-labelledby="title desc"><title id="title">${esc(title)}</title><desc id="desc">${esc(desc)}</desc>${body}</svg>`;
}
function output(name,w,h,body,pngWidths=[w*2]) {
  const source=svg(w,h,body);
  writeFileSync(resolve(root,`dist/svg/${name}.svg`),source);
  for(const width of pngWidths) {
    writeFileSync(resolve(root,`dist/png/${name}-${width}w.png`),new Resvg(source,{fitTo:{mode:'width',value:width}}).render().asPng());
  }
}
for(const d of ['dist/svg','dist/png','dist/social']) mkdirSync(resolve(root,d),{recursive:true});

output('bbuidl-logo-forest',526,190,lockup(30,28,134),[1240,2480]);
output('bbuidl-logo-white',526,190,lockup(30,28,134,C.white),[1240,2480]);
output('bbuidl-logo-black',526,190,lockup(30,28,134,C.black),[1240]);
output('bbuidl-logo-lime',526,190,lockup(30,28,134,C.lime),[1240]);
output('bbuidl-logo-on-paper',526,190,rect(0,0,526,190,C.paper)+lockup(30,28,134),[1240]);
output('bbuidl-logo-on-forest',526,190,rect(0,0,526,190,C.forest)+lockup(30,28,134,C.paper),[1240]);
output('bbuidl-horizontal',340,84,compact(12,12,60),[768,1536]);
output('bbuidl-horizontal-white',340,84,compact(12,12,60,C.white),[768]);
output('bbuidl-mark-forest',167,174,mark(20,20,134),[32,64,256,1024]);
output('bbuidl-mark-white',167,174,mark(20,20,134,C.white),[256,1024]);
output('bbuidl-mark-black',167,174,mark(20,20,134,C.black),[256,1024]);
output('bbuidl-avatar',512,512,rect(0,0,512,512,C.forest)+mark(114,106,300,C.lime),[512,1024]);
output('bbuidl-mark-micro',127,134,mark(0,0,134,C.forest,true),[16,24,32]);
output('bbuidl-favicon',32,32,rect(0,0,32,32,C.forest,7)+mark(4.63,4,24,C.lime,true),[16,32,48,64]);
output('bbuidl-stacked',440,440,mark(163,38,120)+text('BBuidl',75,283,97,C.forest,'Bold',-3.8)+text('AI LAB',157,330,23,C.forest,'Semibold',5)+text('BBuidl.xyz',162,393,19,C.muted),[880]);

// Editorial presentation: generous clearspace, no fake materials, no 3D effects.
let board=rect(0,0,1600,2060,C.paper);
board+=text('BBUIDL AI LAB',72,66,16,C.forest,'Semibold',2.4)+text('VISUAL IDENTITY / 01',1270,66,13,C.forest,'Medium',1.1)+line(72,91,1528,91);
board+=text('Built with intent.',72,160,26,C.forest,'Medium',-.5)+text('A distinctive identity for an AI lab.',1098,158,16,C.muted);
board+=lockup(411,273,224);
board+=text('BBuidl.xyz',746,596,22,C.forest,'Medium',.2);
board+=text('TWO Bs. ONE SHARED STRUCTURE.',72,695,12,C.muted,'Semibold',2)+text('01 / THE SIGNATURE',1355,695,12,C.muted,'Semibold',1.1);
board+=rect(0,741,800,578,C.forest)+rect(800,741,800,578,C.lime);
board+=text('02 / MONOGRAM',48,788,12,C.paper,'Semibold',1.5)+text('03 / INVERSE',848,788,12,C.forest,'Semibold',1.5);
board+=mark(282,869,250,C.lime)+mark(1082,869,250,C.forest);
board+=text('One colour. A complete identity.',48,1270,16,C.paper)+text('Recognisable before you read the name.',848,1270,16,C.forest);
board+=text('Designed to work.',72,1405,34,C.forest,'Semibold',-.9)+text('From a browser tab to a company signature.',72,1440,17,C.muted);
// Website header proof.
board+=rect(72,1486,903,227,C.white,4)+rect(72,1486,903,34,'#E9EAE3',4);
board+='<circle cx="89" cy="1503" r="3" fill="#AEB6AB"/><circle cx="102" cy="1503" r="3" fill="#AEB6AB"/><circle cx="115" cy="1503" r="3" fill="#AEB6AB"/>';
board+=text('bbuidl.xyz',453,1508,11,C.muted)+compact(104,1545,32)+text('Research',688,1567,12)+text('About',784,1567,12)+rect(850,1544,93,34,C.forest,3)+text('Contact',873,1566,11,C.paper,'Semibold');
board+=line(104,1602,943,1602)+text('Ideas, built into intelligence.',104,1655,26,C.forest,'Semibold',-.5);
// A restrained, flat digital business-card application.
board+=rect(1007,1486,521,227,C.forest,4)+compact(1037,1516,34,C.paper)+text('BBuidl.xyz',1037,1678,19,C.lime)+text('AI LAB',1396,1677,12,C.paper,'Semibold',2.2);
board+=text('04 / DIGITAL SIGNATURE',72,1746,11,C.muted,'Semibold',1.3)+text('05 / BRAND CARD',1007,1746,11,C.muted,'Semibold',1.3);
// Small-size proof and colour system.
board+=line(72,1800,1528,1800)+text('Quiet colour. Clear character.',72,1852,23,C.forest,'Semibold',-.4);
board+=rect(72,1878,230,69,C.forest)+rect(314,1878,230,69,C.lime)+rect(556,1878,230,69,C.paper)+'<rect x="556" y="1878" width="230" height="69" fill="none" stroke="#D7DBD1"/>';
board+=text('FOREST / #183E35',87,1920,12,C.paper,'Semibold',.5)+text('CITRON / #D9EF87',329,1920,12,C.forest,'Semibold',.5)+text('PAPER / #F4F1E9',571,1920,12,C.forest,'Semibold',.5);
board+=text('SMALL-SIZE PROOF',1007,1846,11,C.muted,'Semibold',1.3);
for(const [x,size] of [[1007,16],[1105,24],[1211,32],[1333,48]]) {
 board+=mark(x,1905-size,size,C.forest,size<24)+text(`${size} px`,x,1942,11,C.muted);
}
board+=line(72,1991,1528,1991)+text('BBuidl AI Lab',72,2030,13,C.forest,'Semibold')+text('BBuidl.xyz',1437,2030,13,C.forest);
const presentation=svg(1600,2060,board,'BBuidl AI Lab — Visual identity','Brand presentation showing the BB monogram, wordmark, colour system and digital applications.');
writeFileSync(resolve(root,'dist/brand-board.svg'),presentation);
writeFileSync(resolve(root,'dist/brand-board.png'),new Resvg(presentation).render().asPng());

const hero=svg(1600,1000,rect(0,0,1600,1000,C.paper)+text('BBUIDL AI LAB',72,76,15,C.forest,'Semibold',2)+text('BRAND IDENTITY',1324,76,13,C.muted,'Medium',1.5)+line(72,101,1528,101)+lockup(387,333,238)+text('BBuidl.xyz',747,710,22,C.forest)+text('Built with intent.',72,936,18,C.forest)+text('01 / THE SIGNATURE',1338,936,12,C.muted,'Semibold',1));
writeFileSync(resolve(root,'dist/logo-preview.png'),new Resvg(hero).render().asPng());
const social=svg(1200,630,rect(0,0,1200,630,C.forest)+lockup(108,170,191,C.paper)+text('BBuidl.xyz',110,544,23,C.lime)+mark(1034,503,48,C.lime));
writeFileSync(resolve(root,'dist/social/bbuidl-open-graph.png'),new Resvg(social).render().asPng());
// Generate a real multi-resolution ICO container from the validated PNG exports.
const iconSizes=[16,32,48];
const iconPngs=iconSizes.map(size=>new Resvg(svg(32,32,rect(0,0,32,32,C.forest,7)+mark(4.63,4,24,C.lime,true)),{fitTo:{mode:'width',value:size}}).render().asPng());
const header=Buffer.alloc(6+16*iconSizes.length);header.writeUInt16LE(1,2);header.writeUInt16LE(iconSizes.length,4);
let offset=header.length;
iconPngs.forEach((png,i)=>{const o=6+16*i;header[o]=iconSizes[i];header[o+1]=iconSizes[i];header.writeUInt16LE(1,o+4);header.writeUInt16LE(32,o+6);header.writeUInt32LE(png.length,o+8);header.writeUInt32LE(offset,o+12);offset+=png.length;});
writeFileSync(resolve(root,'dist/favicon.ico'),Buffer.concat([header,...iconPngs]));
console.log('Built outlined SVGs, transparent PNGs, brand board, social card and multi-size favicon.');
