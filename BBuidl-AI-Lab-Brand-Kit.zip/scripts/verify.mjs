import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { Resvg } from '@resvg/resvg-js';

let count=0;
for(const name of readdirSync('dist/svg')) {
  const source=readFileSync(`dist/svg/${name}`,'utf8');
  assert(!/<(?:text|image|script|foreignObject)\b/i.test(source),`${name}: must be outlined, self-contained SVG`);
  assert(!/\b(?:href|xlink:href)\s*=/.test(source),`${name}: no external references`);
  assert(source.includes('<title') && source.includes('<desc'),`${name}: accessible metadata`);
  const result=new Resvg(source).render();
  assert(result.width>0 && result.height>0);
  const pixels=result.pixels;
  if(!/on-paper|on-forest|avatar|favicon/.test(name)) {
    let clear=0,paint=0;
    for(let i=3;i<pixels.length;i+=4) {if(pixels[i]===0)clear++;else paint++;}
    assert(clear>0 && paint>0,`${name}: expected transparent background and painted content`);
    // Tight artwork bounds must leave padding on every edge (micro is intentionally edge-aligned).
    if(!name.includes('micro')) {
      let bounds=[result.width,result.height,0,0];
      for(let y=0;y<result.height;y++) for(let x=0;x<result.width;x++) if(pixels[(y*result.width+x)*4+3]>0) {
        bounds=[Math.min(bounds[0],x),Math.min(bounds[1],y),Math.max(bounds[2],x),Math.max(bounds[3],y)];
      }
      assert(bounds[0]>0 && bounds[1]>0 && bounds[2]<result.width-1 && bounds[3]<result.height-1,`${name}: clipping`);
      if(name.includes('logo-')) console.log(`${name}: artwork bounds ${bounds.join(', ')} in ${result.width} × ${result.height}`);
    }
  }
  count++;
}
for(const name of readdirSync('dist/png')) {
  const b=readFileSync(`dist/png/${name}`);
  assert.equal(b.subarray(1,4).toString(),'PNG');
  assert.equal(b.readUInt32BE(16),Number(name.match(/-(\d+)w\.png$/)[1]),`${name}: declared width`);
}
const ico=readFileSync('dist/favicon.ico');
assert.equal(ico.readUInt16LE(2),1);assert.equal(ico.readUInt16LE(4),3);
for(const match of readFileSync('index.html','utf8').matchAll(/(?:src|href)="([^"#]+)"/g)) {
  if(!match[1].startsWith('https:') && !match[1].endsWith('.zip'))assert(existsSync(match[1]),`Missing: ${match[1]}`);
}
console.log(`PASS: ${count} SVGs rendered; outlines, transparency, clipping, PNG dimensions, ICO and local page links verified.`);
